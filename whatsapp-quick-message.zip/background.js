chrome.runtime.onInstalled.addListener(() => {
  console.log('WhatsApp Quick Message Extension Installed');
});
